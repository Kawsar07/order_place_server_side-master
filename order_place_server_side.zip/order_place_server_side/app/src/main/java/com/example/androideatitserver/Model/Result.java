package com.example.androideatitserver.Model;

public class Result {
    public String message_id;
}
